#include <stdint.h>

char *hello_json();
int32_t makeMap(char *str, int length, int64_t port);