Run `win_release\bin\flutter_sys_template.exe`.
Some Microsoft runtimes may need to be installed.
This build is made by manually running `win_release\scripts\build_windows.ps1` on a machine already setup to run the project.
Please look at the `.ps1` script before running as it will delete directories.
